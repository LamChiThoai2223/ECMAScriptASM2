Website bán hàng
Yêu cầu về chức năng
- Khách hàng:
+ Xem danh sách sản phẩm  
+ Xem sản phẩm theo danh mục
+ Thêm sản phẩm vào giỏ hàng
+ Lọc sản phẩm theo khoảng giá, theo danh mục
+ Thêm sản phẩm vào giỏ hàng
+ Thanh toán giỏ hàng
+ Hiển thị màn hình cảm ơn sau khi thanh toán thành công
- Trang quản trị:
+ Quản lý danh mục sản phẩm
+ Quản lý đơn hàng
- Thống kê:
+ Số lượng sản phẩm được đặt mua
+ Thống kê doanh thu
- Thư viện sử dụng:
Firebase: Để lưu trữ và quản lý cơ sở dữ liệu
Tailwind CSS: Để thiết kế giao diện người dùng
Axios: Để gửi các yêu cầu HTTP từ frontend đến backend
Bootstrap: thư viện giúp giao diện website đẹp hơn.
- Tác giả
Tên: Lâm Chí Thoại
Lớp: WD18305
MSSV: PC06821